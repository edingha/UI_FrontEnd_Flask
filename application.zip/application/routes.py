from application import app
from flask import render_template

@app.route("/")
@app.route("/index")
@app.route("/home")
def index():
    return render_template("index.html" )

@app.route("/nlp")
def nlp():
    return render_template("NLP.html" )


@app.route("/ml")
def machinelearning():
    return render_template("Machine_Learning.html" )

@app.route("/bigdata")
def bigdata():
    return render_template("BIG_DATA.html")

@app.route("/cv")
def computervision():
    return render_template("Computer_Vision.html")


@app.route('/ner')
def upload_file():
   return render_template('NER.html')
	
@app.route('/uploader', methods = ['GET', 'POST'])
def uploader():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
      return 'file uploaded successfully'


