# Named-Entity-Extractor
A simple Flask API for named entity extraction using spaCy Model
